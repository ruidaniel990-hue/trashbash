# TrashQuest – Backend API

Node.js + Fastify + PostgreSQL + Prisma

## Setup

```bash
# 1. Abhängigkeiten installieren
npm install

# 2. Umgebungsvariablen konfigurieren
cp .env.example .env
# → .env öffnen und DATABASE_URL + JWT_SECRET eintragen

# 3. Datenbank-Schema anlegen
npm run db:generate
npm run db:migrate

# 4. Entwicklungsserver starten
npm run dev
# → API läuft auf http://localhost:3000
```

## API-Übersicht

| Method | Route | Beschreibung |
|--------|-------|--------------|
| POST | /api/users/register | Neues Konto anlegen |
| POST | /api/users/login | Einloggen, JWT erhalten |
| GET  | /api/users/me | Eigenes Profil + Badges |
| POST | /api/sessions/start | Session starten |
| PATCH| /api/sessions/:id/location | GPS-Position updaten |
| POST | /api/sessions/:id/photo | Müll-Foto hochladen (+Punkte) |
| POST | /api/sessions/:id/end | Session beenden |
| GET  | /api/hotspots?lat=&lng=&radius= | Hotspots in der Nähe |
| POST | /api/hotspots | Hotspot melden (+30 Pts) |
| POST | /api/hotspots/:id/upvote | Hotspot bestätigen |
| POST | /api/hotspots/:id/resolve | Hotspot als bereinigt markieren |
| GET  | /api/ranking?period=week|month|all | Rangliste |
| GET  | /api/ranking/me | Eigene Platzierung |
| GET  | /api/weigh/stations | Alle Wiegestationen |
| POST | /api/weigh/checkin | An Wiegestation einchecken |

## Punkte-System

| Aktion | Punkte |
|--------|--------|
| Plastik-Foto | 15 |
| Glas-Foto | 12 |
| Sperrmüll-Foto | 25 |
| Hotspot melden (hoch) | 30 |
| Hotspot melden (mittel) | 20 |
| Wiegestation 1 kg | 20 |
| Session Distanz | 5/km |
| Hotspot bereinigen | 20 Bonus |

## Level-Schwellen

1→2: 100 Pts · 2→3: 300 · 3→4: 600 · 4→5: 1.000 · 5→6: 1.500
6→7: 2.200 · 7→8: 3.000 · 8→9: 4.000 · 9→10: 5.500 · 10→11: 7.500
